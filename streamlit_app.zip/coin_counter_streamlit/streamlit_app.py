import streamlit as st
import cv2
import numpy as np
from PIL import Image
import io

# ==========================================
# إعدادات الصفحة
# ==========================================
st.set_page_config(
    page_title="عدّاد القطع النقدية",
    page_icon="🪙",
    layout="centered"
)

# CSS بسيط لدعم العربية
st.markdown("""
<style>
    body { direction: rtl; }
    .big-number {
        font-size: 80px;
        font-weight: 900;
        text-align: center;
        color: #F5C842;
        line-height: 1;
    }
    .result-label {
        text-align: center;
        font-size: 18px;
        color: #888;
        margin-top: 5px;
    }
</style>
""", unsafe_allow_html=True)


# ==========================================
# دالة كشف الدوائر — نفس منطق Flask
# ==========================================
def detect_circles(image: np.ndarray):
    original = image.copy()
    height, width = image.shape[:2]

    # تصغير الصورة لو كبيرة
    max_dim = 1200
    scale = 1.0
    if max(height, width) > max_dim:
        scale = max_dim / max(height, width)
        image = cv2.resize(image, (int(width * scale), int(height * scale)))

    # تحويل لرمادي وتمويه
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    blurred = cv2.GaussianBlur(gray, (9, 9), 2)

    h, w = image.shape[:2]
    min_r = max(10, min(h, w) // 40)
    max_r = min(h, w) // 3

    # كشف الدوائر
    circles = cv2.HoughCircles(
        blurred,
        cv2.HOUGH_GRADIENT,
        dp=1.2,
        minDist=min_r * 2,
        param1=80,
        param2=35,
        minRadius=min_r,
        maxRadius=max_r
    )

    count = 0
    result = original.copy()

    if circles is not None:
        circles = np.uint16(np.around(circles))
        count = len(circles[0])

        for i, (x, y, r) in enumerate(circles[0]):
            ox = int(x / scale)
            oy = int(y / scale)
            or_ = int(r / scale)

            # رسم الدائرة الخضراء
            cv2.circle(result, (ox, oy), or_, (0, 220, 120), 3)
            # نقطة المركز
            cv2.circle(result, (ox, oy), 4, (255, 80, 80), -1)
            # الرقم
            label = str(i + 1)
            font_scale = max(0.5, or_ / 40)
            thickness = max(1, int(font_scale * 2))
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
            cv2.putText(result, label, (ox - tw // 2, oy + th // 2),
                        cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), thickness + 2)
            cv2.putText(result, label, (ox - tw // 2, oy + th // 2),
                        cv2.FONT_HERSHEY_SIMPLEX, font_scale, (30, 30, 30), thickness)

    return result, count


# ==========================================
# الواجهة
# ==========================================
st.title("🪙 عدّاد القطع الدائرية")
st.caption("ارفع صورة وسيتم اكتشاف وعد كل الأشكال الدائرية تلقائياً")

st.divider()

# رفع الصورة
uploaded_file = st.file_uploader(
    "اختر صورة",
    type=["jpg", "jpeg", "png", "webp"],
    label_visibility="collapsed"
)

if uploaded_file is not None:
    # قراءة الصورة
    image = Image.open(uploaded_file).convert("RGB")
    img_array = np.array(image)

    # معالجة
    with st.spinner("جاري تحليل الصورة..."):
        result_img, count = detect_circles(img_array)

    # عرض النتيجة العددية
    st.markdown(f'<div class="big-number">{count}</div>', unsafe_allow_html=True)

    if count == 0:
        st.markdown('<div class="result-label">❌ لم يتم اكتشاف أي دوائر</div>', unsafe_allow_html=True)
    elif count == 1:
        st.markdown('<div class="result-label">✅ دائرة واحدة مكتشفة</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="result-label">✅ تم اكتشاف {count} دوائر</div>', unsafe_allow_html=True)

    st.divider()

    # عرض الصورتين جنب بعض
    col1, col2 = st.columns(2)

    with col1:
        st.caption("📷 الصورة الأصلية")
        st.image(image, use_container_width=True)

    with col2:
        st.caption("🟢 النتيجة المعالجة")
        st.image(result_img, use_container_width=True)

    # زر تحميل النتيجة
    st.divider()
    result_pil = Image.fromarray(result_img)
    buf = io.BytesIO()
    result_pil.save(buf, format="JPEG", quality=90)

    st.download_button(
        label="⬇️ تحميل الصورة المعالجة",
        data=buf.getvalue(),
        file_name="result.jpg",
        mime="image/jpeg",
        use_container_width=True
    )

else:
    # تعليمات
    st.info("ارفع صورة فيها قطع نقدية أو أي أشكال دائرية")

    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("💡 **إضاءة جيدة**\n\nتباين واضح بين القطع والخلفية")
    with c2:
        st.markdown("📐 **من فوق مباشرة**\n\nزاوية مستقيمة لأفضل نتائج")
    with c3:
        st.markdown("🔵 **أي دائرة**\n\nقطع، أزرار، ساعات، وغيرها")
